#!/bin/sh

cd /app
socat tcp-listen:9999,fork,reuseaddr exec:./retlibc_stackpivot 2>/dev/null