// gcc admin.c -o admin -lpthread

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>

int is_admin = 0;

void init() {
	setbuf(stdout, 0);
	setbuf(stdin, 0);
}

void try_admin() {
	is_admin = 1;
	usleep(250000);
	is_admin = 0;
}

int main() {
	pthread_t threat;
	int choice;

	init();
	while (1) {
		puts("1. Try admin");
		puts("2. Get shell");
		printf("> ");
		scanf("%d", &choice);
		switch (choice) {
		case 1:
			pthread_create(&threat, NULL, (void*)try_admin, NULL);
			break;
		case 2:
			if (is_admin)
				system("/bin/sh");
			else
				puts("!!! UNAUTHORIZATION IS FORBIDDEN !!!");
			break;
		default:
			puts("Invalid choice!");
		}
	}
}