// gcc -fno-stack-protector -no-pie sigrop.c -o sigrop

#include <stdio.h>
#include <unistd.h>

__asm__(
    ".intel_syntax noprefix;"
    "pop rax;"
    "syscall;"
    ".att_syntax;"
);

int main(int argc, const char **argv, const char **envp)
{
    char buf[16];

    setbuf(stdin, NULL);
    read(0, buf, 0x500);
    return 0;

}