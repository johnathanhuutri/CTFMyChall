#!/bin/sh

env -i /home/me/acceptance 