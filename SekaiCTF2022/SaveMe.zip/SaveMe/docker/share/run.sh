#!/bin/sh

cd /home/user
./saveme