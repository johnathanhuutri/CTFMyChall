#!/bin/sh

exec 2>/dev/null
cd /home/user
./setup