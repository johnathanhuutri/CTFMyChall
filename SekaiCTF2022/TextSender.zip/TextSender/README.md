## Text Sender

### Difficulty: Medium

### Description

I wanted to send multiple messages at one time so I made this text sender. Please try it and give me your opinion, thanks!

### Challenge files

[textsender](textsender)
[libc-2.32.so](libc-2.32.so)
[ld-2.32.so](ld-2.32.so)