#!/bin/sh

cd /home/user
./textsender