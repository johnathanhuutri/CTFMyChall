# Name
rnote

# Description
I've just started learning Rust, so I'll test my skills by writing this simple note app. Please try it out and let me know what you think!

Author: `JohnathanHuuTri`

# Difficulty
hard