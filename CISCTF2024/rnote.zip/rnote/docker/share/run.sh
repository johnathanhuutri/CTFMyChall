#!/bin/sh

cd /app
socat tcp-listen:9002,fork,reuseaddr exec:./rnote
