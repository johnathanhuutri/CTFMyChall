use std::{io::{self, Read, Write}, str::FromStr};

struct Note {
    title: String,
    title_size: usize,
    content: String,
    content_size: usize,
}

static mut LIST: Vec<Note> = Vec::new();

fn read_int() -> i32 {
    let mut input = String::new();

    match io::stdin().read_line(&mut input) {
        Ok(_) => {
            match input.trim().parse::<i32>() {
                Ok(value) => value,
                Err(_) => -1
            }
        },
        Err(_) => -1
    }
}

fn menu() {
    println!("1. Add note");
    println!("2. View note");
    println!("3. Edit note");
    println!("4. Delete note");
    println!("5. Exit");
    print!("> ");
    io::stdout().flush().unwrap();
}

unsafe fn add_note() {
    let mut title: Vec<u8> = Vec::with_capacity(0x100);
    let mut content = String::new();
    
    loop {
        print!("Title size [1-256]: ");
        io::stdout().flush().unwrap();
        let size = read_int();
        if size>0 && size<=0x100 {
            title.set_len(size as usize);
            break;
        }
    }

    print!("Title: ");
    io::stdout().flush().unwrap();
    match io::stdin().read(&mut title) {
        Ok(size) => {
            if title[size-1] == 0xa {
                title[size-1] = 0;
            }
        }
        Err(_) => {}
    }

    print!("Content: ");
    io::stdout().flush().unwrap();
    io::stdin().read_line(&mut content).unwrap();
    if let Ok(tmp) = String::from_str(content.trim()) {
        content = tmp;
    }

    let title_size = title.len();
    let content_size = content.len();
    LIST.push( Note { title: String::from_utf8_unchecked(title), title_size, content, content_size } );
    // String::from_utf8_unchecked(bytes)

    println!("Note added!");
}

unsafe fn view_note() {
    let index;
    let mut title: Vec<u8>;
    let mut content: Vec<u8>;
    
    print!("Index: ");
    io::stdout().flush().unwrap();
    index = read_int();
    if index as usize >= LIST.len() {
        println!("Invalid index!");
        return;
    }

    // let mut title: Vec<u8>;
    // let mut content: Vec<u8>;
    // title = Vec::with_capacity(0x100);
    // title.set_len(LIST[index as usize].title_size);
    // content = Vec::with_capacity(LIST[index as usize].content_size);
    // content.set_len(LIST[index as usize].content_size);
    // std::ptr::copy(LIST[0].title.as_ptr(), title.as_mut_ptr(), LIST[0].title.len());
    // println!("Title: {}", String::from_utf8_unchecked(title));
    // println!("Content: {}", String::from_utf8_unchecked(content));
    title = Vec::with_capacity(0x100);
    title.set_len(LIST[index as usize].title.len());
    std::ptr::copy(LIST[index as usize].title.as_ptr(), title.as_mut_ptr(), LIST[index as usize].title.len());
    println!("Title: {}", String::from_utf8_lossy(&title));

    content = Vec::with_capacity(LIST[index as usize].content.len());
    content.set_len(LIST[index as usize].content.len());
    std::ptr::copy(LIST[index as usize].content.as_ptr(), content.as_mut_ptr(), LIST[index as usize].content.len());
    println!("Content: {}", String::from_utf8_lossy(&content));

    // LIST[0].content_size = 0xffffffff;
    // let mut test = [0xffffffff; 0];
    // let size: i32 = LIST[0].content_size as i32;
    // let mut content: [u8; size] = [0x88; LIST[0].content_size];
    // let mut content: Vec<u8> = Vec::with_capacity(5);
    // std::ptr::copy(LIST[0].content.as_ptr(), content.as_mut_ptr(), LIST[0].content_size);

    // println!("{}", String::from_utf8_lossy(&content));
}

unsafe fn edit_note() {
    let index;
    let mut input = String::new();
    
    print!("Index: ");
    io::stdout().flush().unwrap();
    index = read_int();
    if index as usize >= LIST.len() {
        println!("Invalid index!");
        return;
    }

    loop {
        input.clear();
        print!("Change title? [y/n]: ");
        io::stdout().flush().unwrap();
        io::stdin().read_line(&mut input).unwrap();
        if input.chars().nth(0).unwrap() == 'y' {
            print!("Title: ");
            io::stdout().flush().unwrap();
            match io::stdin().read_line(&mut LIST[index as usize].title) {
                Ok(read_size) => {
                    if let Ok(tmp) = String::from_str(LIST[index as usize].title.trim()) {
                        LIST[index as usize].title = tmp;
                    }
                    LIST[index as usize].title_size = read_size
                },
                Err(_) => {}
            }
            break;
        } else if input.chars().nth(0).unwrap() == 'n' {
            break
        }
    }

    loop {
        input.clear();
        print!("Change content? [y/n]: ");
        io::stdout().flush().unwrap();
        io::stdin().read_line(&mut input).unwrap();
        if input.chars().nth(0).unwrap() == 'y' {
            print!("Content: ");
            io::stdout().flush().unwrap();
            match io::stdin().read_line(&mut LIST[index as usize].content) {
                Ok(read_size) => {
                    println!("{} {}", LIST[index as usize].title_size, LIST[index as usize].content_size);
                    if let Ok(tmp) = String::from_str(LIST[index as usize].content.trim()) {
                        LIST[index as usize].content = tmp;
                    }
                    LIST[index as usize].content_size = read_size
                },
                Err(_) => {
                    println!("Failed to read content!");
                }
            }
            break;
        } else if input.chars().nth(0).unwrap() == 'n' {
            break
        }
    }
}

unsafe fn delete_note() {
    let index;
    
    print!("Index: ");
    io::stdout().flush().unwrap();
    index = read_int();
    if index as usize >= LIST.len() {
        println!("Invalid index!");
        return;
    }
    LIST.remove(index as usize);
    println!("Done!");
}

fn main() {
    
    loop {
        menu();
        match read_int() {
            1 => unsafe { add_note() },
            2 => unsafe { view_note() },
            3 => unsafe { edit_note() },
            4 => unsafe { delete_note() },
            5 => break,
            _ => println!("Invalid option!")
        }
    }
}
