#include <stdio.h>
#include <unistd.h>
#include <dirent.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include <errno.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <alloca.h>

void init()
{
	setbuf(stdin, 0);
	setbuf(stdout, 0);
}

void list() {
	DIR *dir = opendir("data");
	struct dirent *dp;
	int len;

	if (dir == NULL) {
		len = 17;
		write(1, &len, 4);
		write(1, "Failed to opendir", len);
		return;
	}
	while (dir) {
		if ((dp = readdir(dir)) != NULL) {
			if (!strcmp(dp->d_name, ".") || !strcmp(dp->d_name, ".."))
				continue;
			len = strlen(dp->d_name);
			write(1, &len, 4);
			write(1, dp->d_name, len);
		} else {
			len = 0;
			write(1, &len, 4);
			break;
		}
	}
	closedir(dir);
}

void upload() {
	char file_name[0x100], *file_data;
	unsigned int size;
	FILE *f;
	DIR *dir;
	
	dir = opendir("data");
	if (ENOENT == errno) {
		mkdir("data", 0755);
		dir = opendir("data");
	}

	chdir("data");

	// Leak libc address
	read(0, &size, 4);
	if (size >= 0x100)
		return;
	read(0, file_name, size);

	// Create large file
	read(0, &size, 4);
	file_data = malloc(size);
	memset(file_data, 0, size);
	read(0, file_data, size);

	f = fopen(file_name, "w");
	if (f==NULL) {
		return;
	}
	fwrite(file_data, size, 1, f);
	fclose(f);

	free(file_data);
	chdir("..");
	closedir(dir);
}

void download() {
	char file_name[0x100] = {0}, file_data[0x400] = {0};
	DIR *dir;
	struct dirent *dp;
	unsigned int file_size, is_sent = 0;
	FILE *f;

	dir = opendir("data");
	if (ENOENT == errno) {
		mkdir("data", 0755);
		dir = opendir("data");
	}

	chdir("data");
	read(0, file_name, 0x100);
	while (dir) {
		if ((dp = readdir(dir)) != NULL) {
			if (!strcmp(dp->d_name, file_name)) {
				f = fopen(dp->d_name, "r");
				if (f==NULL) {
					return;
				}
				// Get file size
				fseek(f, 0, SEEK_END);
				file_size = ftell(f);
				fseek(f, 0, SEEK_SET);

				fread(file_data, 1, file_size, f);
				write(1, &file_size, 4);
				write(1, file_data, file_size);
				// With libc leaked, we can free stderr
				fclose(f);
				is_sent = 1;
				break;
			}
		} else {
			break;
		}
	}
	if (!is_sent) {
		file_size = 0;
		write(1, &file_size, 4);
	}
	chdir("..");

	// Set dir to null to pass
	closedir(dir);
}

int main()
{
	int is_done = 0;
	char buf[0x20], date[0x30], msg[0x80];
	FILE *f;

	init();

	f = popen("date", "r");
	fgets(date, 0x80, f);
	fclose(f);
	f = fopen("/tmp/log", "a");
	fprintf(f, "New connection at %s", date);
	fclose(f);
	while (!is_done) {
		if (read(0, buf, 1) <= 0){
			break;
		}
		switch(buf[0]) {
			case '1':
				list();
				break;
			case '2':
				upload();
				break;
			case '3':
				download();
				break;
			case '4':
				is_done = 1;
				break;
		}
	}
}