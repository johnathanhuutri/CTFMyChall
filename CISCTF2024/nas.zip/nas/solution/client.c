#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/types.h>          /* See NOTES */
#include <sys/socket.h>
#include <arpa/inet.h>
#include <string.h>

#define MAX_QUEUE 10

void init() {
	setbuf(stdout, 0);
}

void menu() {
	puts("--- MENU ---");
	puts("1. List");
	puts("2. Upload");
	puts("3. Download");
	puts("4. Exit");
	printf("> ");
}

int connect_to_server(char *ip, int port)
{
	int fd;
	struct sockaddr_in serv_addr;

    if ((fd = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
        return -1;
    }

    serv_addr.sin_family = AF_INET;
    serv_addr.sin_port = htons(port);
    if ( inet_pton(AF_INET, ip, &serv_addr.sin_addr) <= 0 ) {
        return -1;
    }

    if ( connect(fd, (struct sockaddr*)&serv_addr, sizeof(serv_addr)) < 0 ) {
        return -1;
    }

    return fd;
}

int main(){
	int fd, is_done = 0, option;
	unsigned int file_size, data_size = 0, sent_size = 0, read_size, queue = 0;
	unsigned int *ptr;
	char *data = NULL;
	char *file_name = malloc(0x100);
	char *file_recv;

	init();
	fd = connect_to_server("127.0.0.1", 9000);
	while (!is_done) {
		menu();
		scanf("%d", &option);
		getchar();

		if (option==4) {
			is_done = 1;
			continue;
		}

		if (option==1) {
			if (fd < 0) {
				puts("Cannot connect to server");
				continue;
			}
			puts("--- LIST ---");
			send(fd, "1", 1, 0);
			for (int i=1; ; i++) {
				if (recv(fd, &file_size, 4, 0)==0) {
					puts("Server disconnected!");
					exit(-1);
				}
				if (!file_size)
					break;
				memset(file_name, 0, 0x100);
				recv(fd, file_name, file_size, 0);
				printf("%d. %s\n", i, file_name);
			}
		} else if (option==2) {
			if (queue < MAX_QUEUE) {
				do {
					printf("File name: ");
					memset(file_name, 0, 0x100);
					read_size = read(0, file_name, 0x100-1);
					if (file_name[read_size - 1] == '\n')
						file_name[read_size - 1] = '\0';
				} while (file_name[0] == '\0');

				do {
					printf("File size: ");
					scanf("%u", &file_size);
					getchar();
					if (file_size > 0x400) {
						puts("File is too big!");
					}
				} while (file_size == 0 || file_size > 0x400);
				printf("Data: ");
				data = realloc(data, data_size + 4 + 0x100 + 4 + file_size);

				ptr = (unsigned int *)&data[data_size];
				*ptr = read_size;
				data_size += 4;
				strcpy(&data[data_size], file_name);
				data_size += 0x100;

				ptr = (unsigned int *)&data[data_size];
				*ptr = file_size;
				data_size += 4;
				read_size = read(0, &data[data_size], *ptr);
				if (data[data_size + read_size - 1] == '\n')
					data[data_size + read_size - 1] = '\0';
				data_size += file_size;
				queue++;
			} else {
				puts("Max queue");
			}

			printf("Do you want to send now or to send later? [1. Now / 2. Later] > ");
			scanf("%d", &option);
			getchar();
			if (option==1) {
				if (fd < 0) {
					puts("Cannot connect to server");
					continue;
				}
				for (int i=0; i<MAX_QUEUE && *((unsigned int *)&data[sent_size]) && *((unsigned int *)&data[sent_size]) < 0x100; i++) {
					send(fd, "2", 1, 0);

					// Send filename
					send(fd, &data[sent_size], 4, 0);
					ptr = (unsigned int *)&data[sent_size];
					sent_size += 4;
					send(fd, &data[sent_size], *ptr, 0);

					// Send data
					sent_size += 0x100;
					send(fd, &data[sent_size], 4, 0);
					ptr = (unsigned int *)&data[sent_size];
					sent_size += 4;
					send(fd, &data[sent_size], *ptr, 0);
					sent_size += *ptr;
				}
				data_size = 0;
				sent_size = 0;
			}
		} else if (option==3) {
			if (fd < 0) {
				puts("Cannot connect to server");
				continue;
			}
			printf("File name: ");
			memset(file_name, 0, 0x100);
			read_size = read(0, file_name, 0x100 - 1);
			if (file_name[read_size - 1] == '\n')
				file_name[read_size - 1] = '\0';

			send(fd, "3", 1, 0);
			send(fd, file_name, read_size, 0);
			recv(fd, &file_size, 4, 0);
			if (!file_size) {
				puts("Invalid filename!");
				continue;
			}
			file_recv = malloc(file_size + 1);
			memset(file_recv, 0, file_size + 1);
			recv(fd, file_recv, file_size, 0);
			puts("--- DATA ---");
			write(1, file_recv, file_size);
			puts("");
			free(file_recv);
		} else {
			puts("Invalid command!");
		}
	}
	send(fd, "4", 1, 0);
	close(fd);

	return 0;
}