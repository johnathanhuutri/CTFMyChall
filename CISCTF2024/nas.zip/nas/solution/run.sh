#!/bin/sh

socat tcp-listen:9000,fork,reuseaddr exec:./server 2>/dev/null &
socat tcp-listen:9001,fork,reuseaddr exec:./client 2>/dev/null &
