# Name
MyNAS

# Description
I have too much files but I don't want to delete any of them so I just decided to create my own NAS device in LAN. But my coding skill is poor, I'm afraid that if it has some bugs, my files could be destroyed. Please help me find and fix those bugs if they are existed, thank you!

Author: `JohnathanHuuTri`

# Difficulty
medium