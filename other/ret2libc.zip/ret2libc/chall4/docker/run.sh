#!/bin/sh

case $1 in
	"start")
		docker compose up --build --detach
		;;

	"stop")
		docker compose down
		;;
esac
