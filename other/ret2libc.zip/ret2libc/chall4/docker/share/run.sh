#!/bin/sh

socat tcp-listen:9004,fork,reuseaddr exec:/app/chall 2>/dev/null