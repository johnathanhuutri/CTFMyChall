#include <stdio.h>
#include <unistd.h>

void init() {
	setbuf(stdin, 0);
	setbuf(stdout, 0);
}

int main() {

	char name[0x20];

	init();
	puts("What is your name?");
	read(0, name, 0x100);
	puts(name);
}