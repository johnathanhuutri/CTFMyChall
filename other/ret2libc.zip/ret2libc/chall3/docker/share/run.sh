#!/bin/sh

socat tcp-listen:9003,fork,reuseaddr exec:/app/chall 2>/dev/null