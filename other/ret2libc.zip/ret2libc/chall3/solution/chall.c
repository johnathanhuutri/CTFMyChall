#include <stdio.h>
#include <unistd.h>

void init() {
	setbuf(stdin, 0);
	setbuf(stdout, 0);
}

int main() {

	char feedback[0x100];
	char name[12];

	init();
	printf("Your name: ");
	fgets(name, 12, stdin);
	printf("Hello ");
	printf(name);
	printf("Your feedback: ");
	fgets(feedback, 0x200, stdin);
	printf("Feedback: %s\n", feedback);
}