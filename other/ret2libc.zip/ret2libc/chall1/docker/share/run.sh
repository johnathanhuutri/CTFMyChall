#!/bin/sh

socat tcp-listen:9001,fork,reuseaddr exec:/app/chall 2>/dev/null