#include <stdio.h>

void init() {
	setbuf(stdout, 0);
}

int main() {
	char buf[0x20];

	init();
	printf("Your input: ");
	fgets(buf, 0x100, stdin);
	puts("Thanks!");
}