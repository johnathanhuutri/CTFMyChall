#!/bin/sh

socat tcp-listen:9002,fork,reuseaddr exec:/app/chall 2>/dev/null