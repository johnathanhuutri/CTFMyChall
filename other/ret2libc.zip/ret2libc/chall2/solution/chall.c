#include <stdio.h>
#include <unistd.h>

void init() {
	setbuf(stdout, 0);
}

void run() {
	char feedback[0x100];
	char name[0x100];

	printf("Your name: ");
	read(0, name, 0x200);
	printf("Name: %s\n", name);
	printf("Your feedback: ");
	read(0, feedback, 0x200);
	printf("Feedback: %s\n", feedback);
}

int main() {
	init();
	run();
}